package com.google.appengine.api.labs.modules;

/**
 * Exception thrown when the given module version name is invalid.
 *
 */
public class InvalidVersionException extends ModulesException {

  InvalidVersionException(String detail) {
    super(detail);
  }
}
