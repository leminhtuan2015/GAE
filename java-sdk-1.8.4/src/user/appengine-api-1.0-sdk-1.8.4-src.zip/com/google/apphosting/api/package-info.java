// Copyright 2012 Google Inc.  All rights reserved.

/**
 * Provides access to the ApiProxy, which dispatches API calls to
 * backend services.
 */
package com.google.apphosting.api;
